using System;
using System.Xml;
using System.Collections.Generic;

namespace Kaltura
{
	public class KalturaAssetParamsBaseFilter : KalturaFilter
	{
		#region Private Fields
		private KalturaNullableBoolean _IsSystemDefaultEqual = (KalturaNullableBoolean)Int32.MinValue;
		private string _TagsEqual = null;
		private KalturaContainerFormat _FormatEqual = null;
		#endregion

		#region Properties
		public KalturaNullableBoolean IsSystemDefaultEqual
		{
			get { return _IsSystemDefaultEqual; }
			set 
			{ 
				_IsSystemDefaultEqual = value;
				OnPropertyChanged("IsSystemDefaultEqual");
			}
		}
		public string TagsEqual
		{
			get { return _TagsEqual; }
			set 
			{ 
				_TagsEqual = value;
				OnPropertyChanged("TagsEqual");
			}
		}
		public KalturaContainerFormat FormatEqual
		{
			get { return _FormatEqual; }
			set 
			{ 
				_FormatEqual = value;
				OnPropertyChanged("FormatEqual");
			}
		}
		#endregion

		#region CTor
		public KalturaAssetParamsBaseFilter()
		{
		}

		public KalturaAssetParamsBaseFilter(XmlElement node) : base(node)
		{
			foreach (XmlElement propertyNode in node.ChildNodes)
			{
				string txt = propertyNode.InnerText;
				switch (propertyNode.Name)
				{
					case "isSystemDefaultEqual":
						this.IsSystemDefaultEqual = (KalturaNullableBoolean)ParseEnum(typeof(KalturaNullableBoolean), txt);
						continue;
					case "tagsEqual":
						this.TagsEqual = txt;
						continue;
					case "formatEqual":
						this.FormatEqual = (KalturaContainerFormat)KalturaStringEnum.Parse(typeof(KalturaContainerFormat), txt);
						continue;
				}
			}
		}
		#endregion

		#region Methods
		public override KalturaParams ToParams()
		{
			KalturaParams kparams = base.ToParams();
			kparams.AddEnumIfNotNull("isSystemDefaultEqual", this.IsSystemDefaultEqual);
			kparams.AddStringIfNotNull("tagsEqual", this.TagsEqual);
			kparams.AddStringEnumIfNotNull("formatEqual", this.FormatEqual);
			return kparams;
		}
		#endregion
	}
}

