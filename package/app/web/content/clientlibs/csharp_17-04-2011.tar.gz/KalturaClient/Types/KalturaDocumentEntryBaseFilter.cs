using System;
using System.Xml;
using System.Collections.Generic;

namespace Kaltura
{
	public class KalturaDocumentEntryBaseFilter : KalturaBaseEntryFilter
	{
		#region Private Fields
		private KalturaDocumentType _DocumentTypeEqual = (KalturaDocumentType)Int32.MinValue;
		private string _DocumentTypeIn = null;
		#endregion

		#region Properties
		public KalturaDocumentType DocumentTypeEqual
		{
			get { return _DocumentTypeEqual; }
			set 
			{ 
				_DocumentTypeEqual = value;
				OnPropertyChanged("DocumentTypeEqual");
			}
		}
		public string DocumentTypeIn
		{
			get { return _DocumentTypeIn; }
			set 
			{ 
				_DocumentTypeIn = value;
				OnPropertyChanged("DocumentTypeIn");
			}
		}
		#endregion

		#region CTor
		public KalturaDocumentEntryBaseFilter()
		{
		}

		public KalturaDocumentEntryBaseFilter(XmlElement node) : base(node)
		{
			foreach (XmlElement propertyNode in node.ChildNodes)
			{
				string txt = propertyNode.InnerText;
				switch (propertyNode.Name)
				{
					case "documentTypeEqual":
						this.DocumentTypeEqual = (KalturaDocumentType)ParseEnum(typeof(KalturaDocumentType), txt);
						continue;
					case "documentTypeIn":
						this.DocumentTypeIn = txt;
						continue;
				}
			}
		}
		#endregion

		#region Methods
		public override KalturaParams ToParams()
		{
			KalturaParams kparams = base.ToParams();
			kparams.AddEnumIfNotNull("documentTypeEqual", this.DocumentTypeEqual);
			kparams.AddStringIfNotNull("documentTypeIn", this.DocumentTypeIn);
			return kparams;
		}
		#endregion
	}
}

