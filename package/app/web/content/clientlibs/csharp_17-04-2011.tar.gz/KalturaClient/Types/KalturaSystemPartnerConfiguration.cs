using System;
using System.Xml;
using System.Collections.Generic;

namespace Kaltura
{
	public class KalturaSystemPartnerConfiguration : KalturaObjectBase
	{
		#region Private Fields
		private string _PartnerName = null;
		private string _Description = null;
		private string _AdminName = null;
		private string _AdminEmail = null;
		private string _Host = null;
		private string _CdnHost = null;
		private int _MaxBulkSize = Int32.MinValue;
		private int _PartnerPackage = Int32.MinValue;
		private int _MonitorUsage = Int32.MinValue;
		private bool? _LiveStreamEnabled = false;
		private bool? _ModerateContent = false;
		private string _RtmpUrl = null;
		private bool? _StorageDeleteFromKaltura = false;
		private KalturaStorageServePriority _StorageServePriority = (KalturaStorageServePriority)Int32.MinValue;
		private int _KmcVersion = Int32.MinValue;
		private bool? _EnableAnalyticsTab = false;
		private bool? _EnableSilverLight = false;
		private bool? _EnableVast = false;
		private bool? _Enable508Players = false;
		private bool? _EnableMetadata = false;
		private bool? _EnableContentDistribution = false;
		private bool? _EnableAuditTrail = false;
		private bool? _EnableAnnotation = false;
		private bool? _EnableMobileFlavors = false;
		private bool? _EnablePs2PermissionValidation = false;
		private int _DefThumbOffset = Int32.MinValue;
		private int _AdminLoginUsersQuota = Int32.MinValue;
		private int _UserSessionRoleId = Int32.MinValue;
		private int _AdminSessionRoleId = Int32.MinValue;
		private string _AlwaysAllowedPermissionNames = null;
		#endregion

		#region Properties
		public string PartnerName
		{
			get { return _PartnerName; }
			set 
			{ 
				_PartnerName = value;
				OnPropertyChanged("PartnerName");
			}
		}
		public string Description
		{
			get { return _Description; }
			set 
			{ 
				_Description = value;
				OnPropertyChanged("Description");
			}
		}
		public string AdminName
		{
			get { return _AdminName; }
			set 
			{ 
				_AdminName = value;
				OnPropertyChanged("AdminName");
			}
		}
		public string AdminEmail
		{
			get { return _AdminEmail; }
			set 
			{ 
				_AdminEmail = value;
				OnPropertyChanged("AdminEmail");
			}
		}
		public string Host
		{
			get { return _Host; }
			set 
			{ 
				_Host = value;
				OnPropertyChanged("Host");
			}
		}
		public string CdnHost
		{
			get { return _CdnHost; }
			set 
			{ 
				_CdnHost = value;
				OnPropertyChanged("CdnHost");
			}
		}
		public int MaxBulkSize
		{
			get { return _MaxBulkSize; }
			set 
			{ 
				_MaxBulkSize = value;
				OnPropertyChanged("MaxBulkSize");
			}
		}
		public int PartnerPackage
		{
			get { return _PartnerPackage; }
			set 
			{ 
				_PartnerPackage = value;
				OnPropertyChanged("PartnerPackage");
			}
		}
		public int MonitorUsage
		{
			get { return _MonitorUsage; }
			set 
			{ 
				_MonitorUsage = value;
				OnPropertyChanged("MonitorUsage");
			}
		}
		public bool? LiveStreamEnabled
		{
			get { return _LiveStreamEnabled; }
			set 
			{ 
				_LiveStreamEnabled = value;
				OnPropertyChanged("LiveStreamEnabled");
			}
		}
		public bool? ModerateContent
		{
			get { return _ModerateContent; }
			set 
			{ 
				_ModerateContent = value;
				OnPropertyChanged("ModerateContent");
			}
		}
		public string RtmpUrl
		{
			get { return _RtmpUrl; }
			set 
			{ 
				_RtmpUrl = value;
				OnPropertyChanged("RtmpUrl");
			}
		}
		public bool? StorageDeleteFromKaltura
		{
			get { return _StorageDeleteFromKaltura; }
			set 
			{ 
				_StorageDeleteFromKaltura = value;
				OnPropertyChanged("StorageDeleteFromKaltura");
			}
		}
		public KalturaStorageServePriority StorageServePriority
		{
			get { return _StorageServePriority; }
			set 
			{ 
				_StorageServePriority = value;
				OnPropertyChanged("StorageServePriority");
			}
		}
		public int KmcVersion
		{
			get { return _KmcVersion; }
			set 
			{ 
				_KmcVersion = value;
				OnPropertyChanged("KmcVersion");
			}
		}
		public bool? EnableAnalyticsTab
		{
			get { return _EnableAnalyticsTab; }
			set 
			{ 
				_EnableAnalyticsTab = value;
				OnPropertyChanged("EnableAnalyticsTab");
			}
		}
		public bool? EnableSilverLight
		{
			get { return _EnableSilverLight; }
			set 
			{ 
				_EnableSilverLight = value;
				OnPropertyChanged("EnableSilverLight");
			}
		}
		public bool? EnableVast
		{
			get { return _EnableVast; }
			set 
			{ 
				_EnableVast = value;
				OnPropertyChanged("EnableVast");
			}
		}
		public bool? Enable508Players
		{
			get { return _Enable508Players; }
			set 
			{ 
				_Enable508Players = value;
				OnPropertyChanged("Enable508Players");
			}
		}
		public bool? EnableMetadata
		{
			get { return _EnableMetadata; }
			set 
			{ 
				_EnableMetadata = value;
				OnPropertyChanged("EnableMetadata");
			}
		}
		public bool? EnableContentDistribution
		{
			get { return _EnableContentDistribution; }
			set 
			{ 
				_EnableContentDistribution = value;
				OnPropertyChanged("EnableContentDistribution");
			}
		}
		public bool? EnableAuditTrail
		{
			get { return _EnableAuditTrail; }
			set 
			{ 
				_EnableAuditTrail = value;
				OnPropertyChanged("EnableAuditTrail");
			}
		}
		public bool? EnableAnnotation
		{
			get { return _EnableAnnotation; }
			set 
			{ 
				_EnableAnnotation = value;
				OnPropertyChanged("EnableAnnotation");
			}
		}
		public bool? EnableMobileFlavors
		{
			get { return _EnableMobileFlavors; }
			set 
			{ 
				_EnableMobileFlavors = value;
				OnPropertyChanged("EnableMobileFlavors");
			}
		}
		public bool? EnablePs2PermissionValidation
		{
			get { return _EnablePs2PermissionValidation; }
			set 
			{ 
				_EnablePs2PermissionValidation = value;
				OnPropertyChanged("EnablePs2PermissionValidation");
			}
		}
		public int DefThumbOffset
		{
			get { return _DefThumbOffset; }
			set 
			{ 
				_DefThumbOffset = value;
				OnPropertyChanged("DefThumbOffset");
			}
		}
		public int AdminLoginUsersQuota
		{
			get { return _AdminLoginUsersQuota; }
			set 
			{ 
				_AdminLoginUsersQuota = value;
				OnPropertyChanged("AdminLoginUsersQuota");
			}
		}
		public int UserSessionRoleId
		{
			get { return _UserSessionRoleId; }
			set 
			{ 
				_UserSessionRoleId = value;
				OnPropertyChanged("UserSessionRoleId");
			}
		}
		public int AdminSessionRoleId
		{
			get { return _AdminSessionRoleId; }
			set 
			{ 
				_AdminSessionRoleId = value;
				OnPropertyChanged("AdminSessionRoleId");
			}
		}
		public string AlwaysAllowedPermissionNames
		{
			get { return _AlwaysAllowedPermissionNames; }
			set 
			{ 
				_AlwaysAllowedPermissionNames = value;
				OnPropertyChanged("AlwaysAllowedPermissionNames");
			}
		}
		#endregion

		#region CTor
		public KalturaSystemPartnerConfiguration()
		{
		}

		public KalturaSystemPartnerConfiguration(XmlElement node)
		{
			foreach (XmlElement propertyNode in node.ChildNodes)
			{
				string txt = propertyNode.InnerText;
				switch (propertyNode.Name)
				{
					case "partnerName":
						this.PartnerName = txt;
						continue;
					case "description":
						this.Description = txt;
						continue;
					case "adminName":
						this.AdminName = txt;
						continue;
					case "adminEmail":
						this.AdminEmail = txt;
						continue;
					case "host":
						this.Host = txt;
						continue;
					case "cdnHost":
						this.CdnHost = txt;
						continue;
					case "maxBulkSize":
						this.MaxBulkSize = ParseInt(txt);
						continue;
					case "partnerPackage":
						this.PartnerPackage = ParseInt(txt);
						continue;
					case "monitorUsage":
						this.MonitorUsage = ParseInt(txt);
						continue;
					case "liveStreamEnabled":
						this.LiveStreamEnabled = ParseBool(txt);
						continue;
					case "moderateContent":
						this.ModerateContent = ParseBool(txt);
						continue;
					case "rtmpUrl":
						this.RtmpUrl = txt;
						continue;
					case "storageDeleteFromKaltura":
						this.StorageDeleteFromKaltura = ParseBool(txt);
						continue;
					case "storageServePriority":
						this.StorageServePriority = (KalturaStorageServePriority)ParseEnum(typeof(KalturaStorageServePriority), txt);
						continue;
					case "kmcVersion":
						this.KmcVersion = ParseInt(txt);
						continue;
					case "enableAnalyticsTab":
						this.EnableAnalyticsTab = ParseBool(txt);
						continue;
					case "enableSilverLight":
						this.EnableSilverLight = ParseBool(txt);
						continue;
					case "enableVast":
						this.EnableVast = ParseBool(txt);
						continue;
					case "enable508Players":
						this.Enable508Players = ParseBool(txt);
						continue;
					case "enableMetadata":
						this.EnableMetadata = ParseBool(txt);
						continue;
					case "enableContentDistribution":
						this.EnableContentDistribution = ParseBool(txt);
						continue;
					case "enableAuditTrail":
						this.EnableAuditTrail = ParseBool(txt);
						continue;
					case "enableAnnotation":
						this.EnableAnnotation = ParseBool(txt);
						continue;
					case "enableMobileFlavors":
						this.EnableMobileFlavors = ParseBool(txt);
						continue;
					case "enablePs2PermissionValidation":
						this.EnablePs2PermissionValidation = ParseBool(txt);
						continue;
					case "defThumbOffset":
						this.DefThumbOffset = ParseInt(txt);
						continue;
					case "adminLoginUsersQuota":
						this.AdminLoginUsersQuota = ParseInt(txt);
						continue;
					case "userSessionRoleId":
						this.UserSessionRoleId = ParseInt(txt);
						continue;
					case "adminSessionRoleId":
						this.AdminSessionRoleId = ParseInt(txt);
						continue;
					case "alwaysAllowedPermissionNames":
						this.AlwaysAllowedPermissionNames = txt;
						continue;
				}
			}
		}
		#endregion

		#region Methods
		public override KalturaParams ToParams()
		{
			KalturaParams kparams = base.ToParams();
			kparams.AddStringIfNotNull("partnerName", this.PartnerName);
			kparams.AddStringIfNotNull("description", this.Description);
			kparams.AddStringIfNotNull("adminName", this.AdminName);
			kparams.AddStringIfNotNull("adminEmail", this.AdminEmail);
			kparams.AddStringIfNotNull("host", this.Host);
			kparams.AddStringIfNotNull("cdnHost", this.CdnHost);
			kparams.AddIntIfNotNull("maxBulkSize", this.MaxBulkSize);
			kparams.AddIntIfNotNull("partnerPackage", this.PartnerPackage);
			kparams.AddIntIfNotNull("monitorUsage", this.MonitorUsage);
			kparams.AddBoolIfNotNull("liveStreamEnabled", this.LiveStreamEnabled);
			kparams.AddBoolIfNotNull("moderateContent", this.ModerateContent);
			kparams.AddStringIfNotNull("rtmpUrl", this.RtmpUrl);
			kparams.AddBoolIfNotNull("storageDeleteFromKaltura", this.StorageDeleteFromKaltura);
			kparams.AddEnumIfNotNull("storageServePriority", this.StorageServePriority);
			kparams.AddIntIfNotNull("kmcVersion", this.KmcVersion);
			kparams.AddBoolIfNotNull("enableAnalyticsTab", this.EnableAnalyticsTab);
			kparams.AddBoolIfNotNull("enableSilverLight", this.EnableSilverLight);
			kparams.AddBoolIfNotNull("enableVast", this.EnableVast);
			kparams.AddBoolIfNotNull("enable508Players", this.Enable508Players);
			kparams.AddBoolIfNotNull("enableMetadata", this.EnableMetadata);
			kparams.AddBoolIfNotNull("enableContentDistribution", this.EnableContentDistribution);
			kparams.AddBoolIfNotNull("enableAuditTrail", this.EnableAuditTrail);
			kparams.AddBoolIfNotNull("enableAnnotation", this.EnableAnnotation);
			kparams.AddBoolIfNotNull("enableMobileFlavors", this.EnableMobileFlavors);
			kparams.AddBoolIfNotNull("enablePs2PermissionValidation", this.EnablePs2PermissionValidation);
			kparams.AddIntIfNotNull("defThumbOffset", this.DefThumbOffset);
			kparams.AddIntIfNotNull("adminLoginUsersQuota", this.AdminLoginUsersQuota);
			kparams.AddIntIfNotNull("userSessionRoleId", this.UserSessionRoleId);
			kparams.AddIntIfNotNull("adminSessionRoleId", this.AdminSessionRoleId);
			kparams.AddStringIfNotNull("alwaysAllowedPermissionNames", this.AlwaysAllowedPermissionNames);
			return kparams;
		}
		#endregion
	}
}

