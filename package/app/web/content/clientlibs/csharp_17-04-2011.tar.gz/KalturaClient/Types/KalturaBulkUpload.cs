using System;
using System.Xml;
using System.Collections.Generic;

namespace Kaltura
{
	public class KalturaBulkUpload : KalturaObjectBase
	{
		#region Private Fields
		private int _Id = Int32.MinValue;
		private string _UploadedBy = null;
		private string _UploadedByUserId = null;
		private int _UploadedOn = Int32.MinValue;
		private int _NumOfEntries = Int32.MinValue;
		private KalturaBatchJobStatus _Status = (KalturaBatchJobStatus)Int32.MinValue;
		private string _LogFileUrl = null;
		private string _CsvFileUrl = null;
		private IList<KalturaBulkUploadResult> _Results;
		#endregion

		#region Properties
		public int Id
		{
			get { return _Id; }
			set 
			{ 
				_Id = value;
				OnPropertyChanged("Id");
			}
		}
		public string UploadedBy
		{
			get { return _UploadedBy; }
			set 
			{ 
				_UploadedBy = value;
				OnPropertyChanged("UploadedBy");
			}
		}
		public string UploadedByUserId
		{
			get { return _UploadedByUserId; }
			set 
			{ 
				_UploadedByUserId = value;
				OnPropertyChanged("UploadedByUserId");
			}
		}
		public int UploadedOn
		{
			get { return _UploadedOn; }
			set 
			{ 
				_UploadedOn = value;
				OnPropertyChanged("UploadedOn");
			}
		}
		public int NumOfEntries
		{
			get { return _NumOfEntries; }
			set 
			{ 
				_NumOfEntries = value;
				OnPropertyChanged("NumOfEntries");
			}
		}
		public KalturaBatchJobStatus Status
		{
			get { return _Status; }
			set 
			{ 
				_Status = value;
				OnPropertyChanged("Status");
			}
		}
		public string LogFileUrl
		{
			get { return _LogFileUrl; }
			set 
			{ 
				_LogFileUrl = value;
				OnPropertyChanged("LogFileUrl");
			}
		}
		public string CsvFileUrl
		{
			get { return _CsvFileUrl; }
			set 
			{ 
				_CsvFileUrl = value;
				OnPropertyChanged("CsvFileUrl");
			}
		}
		public IList<KalturaBulkUploadResult> Results
		{
			get { return _Results; }
			set 
			{ 
				_Results = value;
				OnPropertyChanged("Results");
			}
		}
		#endregion

		#region CTor
		public KalturaBulkUpload()
		{
		}

		public KalturaBulkUpload(XmlElement node)
		{
			foreach (XmlElement propertyNode in node.ChildNodes)
			{
				string txt = propertyNode.InnerText;
				switch (propertyNode.Name)
				{
					case "id":
						this.Id = ParseInt(txt);
						continue;
					case "uploadedBy":
						this.UploadedBy = txt;
						continue;
					case "uploadedByUserId":
						this.UploadedByUserId = txt;
						continue;
					case "uploadedOn":
						this.UploadedOn = ParseInt(txt);
						continue;
					case "numOfEntries":
						this.NumOfEntries = ParseInt(txt);
						continue;
					case "status":
						this.Status = (KalturaBatchJobStatus)ParseEnum(typeof(KalturaBatchJobStatus), txt);
						continue;
					case "logFileUrl":
						this.LogFileUrl = txt;
						continue;
					case "csvFileUrl":
						this.CsvFileUrl = txt;
						continue;
					case "results":
						this.Results = new List<KalturaBulkUploadResult>();
						foreach(XmlElement arrayNode in propertyNode.ChildNodes)
						{
							this.Results.Add((KalturaBulkUploadResult)KalturaObjectFactory.Create(arrayNode));
						}
						continue;
				}
			}
		}
		#endregion

		#region Methods
		public override KalturaParams ToParams()
		{
			KalturaParams kparams = base.ToParams();
			kparams.AddIntIfNotNull("id", this.Id);
			kparams.AddStringIfNotNull("uploadedBy", this.UploadedBy);
			kparams.AddStringIfNotNull("uploadedByUserId", this.UploadedByUserId);
			kparams.AddIntIfNotNull("uploadedOn", this.UploadedOn);
			kparams.AddIntIfNotNull("numOfEntries", this.NumOfEntries);
			kparams.AddEnumIfNotNull("status", this.Status);
			kparams.AddStringIfNotNull("logFileUrl", this.LogFileUrl);
			kparams.AddStringIfNotNull("csvFileUrl", this.CsvFileUrl);
			if (this.Results != null)
			{
				int i = 0;
				foreach (KalturaBulkUploadResult item in this.Results)
				{
					kparams.Add("results:" + i + ":objectType", item.GetType().Name);
					kparams.Add("results:" + i, item.ToParams());
					i++;
				}
			}
			return kparams;
		}
		#endregion
	}
}

