using System;
using System.Xml;
using System.Collections.Generic;
using System.IO;

namespace Kaltura
{

	public class KalturaUiConfAdminService : KalturaServiceBase
	{
	public KalturaUiConfAdminService(KalturaClient client)
			: base(client)
		{
		}

		public KalturaUiConfAdmin Add(KalturaUiConfAdmin uiConf)
		{
			KalturaParams kparams = new KalturaParams();
			if (uiConf != null)
				kparams.Add("uiConf", uiConf.ToParams());
			_Client.QueueServiceCall("adminconsole_uiconfadmin", "add", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaUiConfAdmin)KalturaObjectFactory.Create(result);
		}

		public KalturaUiConfAdmin Update(int id, KalturaUiConfAdmin uiConf)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddIntIfNotNull("id", id);
			if (uiConf != null)
				kparams.Add("uiConf", uiConf.ToParams());
			_Client.QueueServiceCall("adminconsole_uiconfadmin", "update", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaUiConfAdmin)KalturaObjectFactory.Create(result);
		}

		public KalturaUiConfAdmin Get(int id)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddIntIfNotNull("id", id);
			_Client.QueueServiceCall("adminconsole_uiconfadmin", "get", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaUiConfAdmin)KalturaObjectFactory.Create(result);
		}

		public void Delete(int id)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddIntIfNotNull("id", id);
			_Client.QueueServiceCall("adminconsole_uiconfadmin", "delete", kparams);
			if (this._Client.IsMultiRequest)
				return;
			XmlElement result = _Client.DoQueue();
		}

		public KalturaUiConfAdminListResponse List()
		{
			return this.List(null);
		}

		public KalturaUiConfAdminListResponse List(KalturaUiConfFilter filter)
		{
			return this.List(filter, null);
		}

		public KalturaUiConfAdminListResponse List(KalturaUiConfFilter filter, KalturaFilterPager pager)
		{
			KalturaParams kparams = new KalturaParams();
			if (filter != null)
				kparams.Add("filter", filter.ToParams());
			if (pager != null)
				kparams.Add("pager", pager.ToParams());
			_Client.QueueServiceCall("adminconsole_uiconfadmin", "list", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaUiConfAdminListResponse)KalturaObjectFactory.Create(result);
		}
	}
}
