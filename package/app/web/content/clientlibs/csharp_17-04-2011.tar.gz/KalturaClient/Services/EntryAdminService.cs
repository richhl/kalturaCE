using System;
using System.Xml;
using System.Collections.Generic;
using System.IO;

namespace Kaltura
{

	public class KalturaEntryAdminService : KalturaServiceBase
	{
	public KalturaEntryAdminService(KalturaClient client)
			: base(client)
		{
		}

		public KalturaBaseEntry Get(string entryId)
		{
			return this.Get(entryId, -1);
		}

		public KalturaBaseEntry Get(string entryId, int version)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddStringIfNotNull("entryId", entryId);
			kparams.AddIntIfNotNull("version", version);
			_Client.QueueServiceCall("adminconsole_entryadmin", "get", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaBaseEntry)KalturaObjectFactory.Create(result);
		}

		public KalturaBaseEntry GetByFlavorId(string flavorId)
		{
			return this.GetByFlavorId(flavorId, -1);
		}

		public KalturaBaseEntry GetByFlavorId(string flavorId, int version)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddStringIfNotNull("flavorId", flavorId);
			kparams.AddIntIfNotNull("version", version);
			_Client.QueueServiceCall("adminconsole_entryadmin", "getByFlavorId", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaBaseEntry)KalturaObjectFactory.Create(result);
		}

		public KalturaTrackEntryListResponse GetTracks(string entryId)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddStringIfNotNull("entryId", entryId);
			_Client.QueueServiceCall("adminconsole_entryadmin", "getTracks", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaTrackEntryListResponse)KalturaObjectFactory.Create(result);
		}
	}
}
