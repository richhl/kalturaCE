using System;
using System.Xml;
using System.Collections.Generic;
using System.IO;

namespace Kaltura
{

	public class KalturaStorageProfileService : KalturaServiceBase
	{
	public KalturaStorageProfileService(KalturaClient client)
			: base(client)
		{
		}

		public KalturaStorageProfileListResponse ListByPartner()
		{
			return this.ListByPartner(null);
		}

		public KalturaStorageProfileListResponse ListByPartner(KalturaPartnerFilter filter)
		{
			return this.ListByPartner(filter, null);
		}

		public KalturaStorageProfileListResponse ListByPartner(KalturaPartnerFilter filter, KalturaFilterPager pager)
		{
			KalturaParams kparams = new KalturaParams();
			if (filter != null)
				kparams.Add("filter", filter.ToParams());
			if (pager != null)
				kparams.Add("pager", pager.ToParams());
			_Client.QueueServiceCall("storageprofile_storageprofile", "listByPartner", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaStorageProfileListResponse)KalturaObjectFactory.Create(result);
		}

		public void UpdateStatus(int storageId, KalturaStorageProfileStatus status)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddIntIfNotNull("storageId", storageId);
			kparams.AddEnumIfNotNull("status", status);
			_Client.QueueServiceCall("storageprofile_storageprofile", "updateStatus", kparams);
			if (this._Client.IsMultiRequest)
				return;
			XmlElement result = _Client.DoQueue();
		}

		public KalturaStorageProfile Get(int storageProfileId)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddIntIfNotNull("storageProfileId", storageProfileId);
			_Client.QueueServiceCall("storageprofile_storageprofile", "get", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaStorageProfile)KalturaObjectFactory.Create(result);
		}

		public KalturaStorageProfile Update(int storageProfileId, KalturaStorageProfile storageProfile)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddIntIfNotNull("storageProfileId", storageProfileId);
			if (storageProfile != null)
				kparams.Add("storageProfile", storageProfile.ToParams());
			_Client.QueueServiceCall("storageprofile_storageprofile", "update", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaStorageProfile)KalturaObjectFactory.Create(result);
		}

		public KalturaStorageProfile Add(KalturaStorageProfile storageProfile)
		{
			KalturaParams kparams = new KalturaParams();
			if (storageProfile != null)
				kparams.Add("storageProfile", storageProfile.ToParams());
			_Client.QueueServiceCall("storageprofile_storageprofile", "add", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaStorageProfile)KalturaObjectFactory.Create(result);
		}
	}
}
