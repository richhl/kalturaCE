using System;
using System.Xml;
using System.Collections.Generic;
using System.IO;

namespace Kaltura
{

	public class KalturaAnnotationService : KalturaServiceBase
	{
	public KalturaAnnotationService(KalturaClient client)
			: base(client)
		{
		}

		public KalturaAnnotationListResponse List()
		{
			return this.List(null);
		}

		public KalturaAnnotationListResponse List(KalturaAnnotationFilter filter)
		{
			return this.List(filter, null);
		}

		public KalturaAnnotationListResponse List(KalturaAnnotationFilter filter, KalturaFilterPager pager)
		{
			KalturaParams kparams = new KalturaParams();
			if (filter != null)
				kparams.Add("filter", filter.ToParams());
			if (pager != null)
				kparams.Add("pager", pager.ToParams());
			_Client.QueueServiceCall("annotation_annotation", "list", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaAnnotationListResponse)KalturaObjectFactory.Create(result);
		}

		public KalturaAnnotation Add(KalturaAnnotation annotation)
		{
			KalturaParams kparams = new KalturaParams();
			if (annotation != null)
				kparams.Add("annotation", annotation.ToParams());
			_Client.QueueServiceCall("annotation_annotation", "add", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaAnnotation)KalturaObjectFactory.Create(result);
		}

		public KalturaAnnotation Get(string id)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddStringIfNotNull("id", id);
			_Client.QueueServiceCall("annotation_annotation", "get", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaAnnotation)KalturaObjectFactory.Create(result);
		}

		public void Delete(string id)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddStringIfNotNull("id", id);
			_Client.QueueServiceCall("annotation_annotation", "delete", kparams);
			if (this._Client.IsMultiRequest)
				return;
			XmlElement result = _Client.DoQueue();
		}

		public KalturaAnnotation Update(string id, KalturaAnnotation annotation)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddStringIfNotNull("id", id);
			if (annotation != null)
				kparams.Add("annotation", annotation.ToParams());
			_Client.QueueServiceCall("annotation_annotation", "update", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaAnnotation)KalturaObjectFactory.Create(result);
		}
	}
}
