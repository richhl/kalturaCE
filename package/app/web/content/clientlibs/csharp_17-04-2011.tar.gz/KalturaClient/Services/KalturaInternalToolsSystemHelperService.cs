using System;
using System.Xml;
using System.Collections.Generic;
using System.IO;

namespace Kaltura
{

	public class KalturaKalturaInternalToolsSystemHelperService : KalturaServiceBase
	{
	public KalturaKalturaInternalToolsSystemHelperService(KalturaClient client)
			: base(client)
		{
		}

		public KalturaInternalToolsSession FromSecureString(string str)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddStringIfNotNull("str", str);
			_Client.QueueServiceCall("kalturainternaltools_kalturainternaltoolssystemhelper", "fromSecureString", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaInternalToolsSession)KalturaObjectFactory.Create(result);
		}

		public string Iptocountry(string remote_addr)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddStringIfNotNull("remote_addr", remote_addr);
			_Client.QueueServiceCall("kalturainternaltools_kalturainternaltoolssystemhelper", "iptocountry", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return result.InnerText;
		}

		public string GetRemoteAddress()
		{
			KalturaParams kparams = new KalturaParams();
			_Client.QueueServiceCall("kalturainternaltools_kalturainternaltoolssystemhelper", "getRemoteAddress", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return result.InnerText;
		}
	}
}
