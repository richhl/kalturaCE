namespace Kaltura
{
	public enum KalturaAuditTrailStatus
	{
		PENDING = 1,
		READY = 2,
		FAILED = 3,
	}
}
