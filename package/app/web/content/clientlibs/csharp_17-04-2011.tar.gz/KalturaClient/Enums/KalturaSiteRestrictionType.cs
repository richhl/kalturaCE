namespace Kaltura
{
	public enum KalturaSiteRestrictionType
	{
		RESTRICT_SITE_LIST = 0,
		ALLOW_SITE_LIST = 1,
	}
}
