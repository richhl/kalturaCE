namespace Kaltura
{
	public sealed class KalturaAssetParamsOrderBy : KalturaStringEnum
	{

		private KalturaAssetParamsOrderBy(string name) : base(name) { }
	}
}
