namespace Kaltura
{
	public enum KalturaPartnerStatus
	{
		ACTIVE = 1,
		BLOCKED = 2,
		FULL_BLOCK = 3,
	}
}
