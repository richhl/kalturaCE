namespace Kaltura
{
	public enum KalturaUserRoleStatus
	{
		ACTIVE = 1,
		BLOCKED = 2,
		DELETED = 3,
	}
}
