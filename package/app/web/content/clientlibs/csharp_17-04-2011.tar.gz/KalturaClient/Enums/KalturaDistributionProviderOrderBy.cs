namespace Kaltura
{
	public sealed class KalturaDistributionProviderOrderBy : KalturaStringEnum
	{

		private KalturaDistributionProviderOrderBy(string name) : base(name) { }
	}
}
