namespace Kaltura
{
	public enum KalturaCommercialUseType
	{
		COMMERCIAL_USE = 1,
		NON_COMMERCIAL_USE = 0,
	}
}
