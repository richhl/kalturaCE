namespace Kaltura
{
	public enum KalturaBatchJobErrorTypes
	{
		APP = 0,
		RUNTIME = 1,
		HTTP = 2,
		CURL = 3,
		KALTURA_API = 4,
		KALTURA_CLIENT = 5,
	}
}
