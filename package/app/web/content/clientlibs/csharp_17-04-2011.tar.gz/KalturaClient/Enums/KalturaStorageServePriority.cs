namespace Kaltura
{
	public enum KalturaStorageServePriority
	{
		KALTURA_ONLY = 1,
		KALTURA_FIRST = 2,
		EXTERNAL_FIRST = 3,
		EXTERNAL_ONLY = 4,
	}
}
