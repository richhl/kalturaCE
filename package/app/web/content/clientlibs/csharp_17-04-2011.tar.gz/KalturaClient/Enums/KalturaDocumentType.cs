namespace Kaltura
{
	public enum KalturaDocumentType
	{
		DOCUMENT = 11,
		SWF = 12,
		PDF = 13,
	}
}
