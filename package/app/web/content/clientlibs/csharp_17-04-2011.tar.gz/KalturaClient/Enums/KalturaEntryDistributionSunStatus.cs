namespace Kaltura
{
	public enum KalturaEntryDistributionSunStatus
	{
		BEFORE_SUNRISE = 1,
		AFTER_SUNRISE = 2,
		AFTER_SUNSET = 3,
	}
}
