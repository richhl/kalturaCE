namespace Kaltura
{
	public enum KalturaControlPanelCommandType
	{
		STOP = 1,
		START = 2,
		CONFIG = 3,
		KILL = 4,
	}
}
