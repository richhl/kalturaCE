namespace Kaltura
{
	public enum KalturaThumbCropType
	{
		RESIZE = 1,
		RESIZE_WITH_PADDING = 2,
		CROP = 3,
		CROP_FROM_TOP = 4,
	}
}
