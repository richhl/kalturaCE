namespace Kaltura
{
	public enum KalturaDistributionAction
	{
		SUBMIT = 1,
		UPDATE = 2,
		DELETE = 3,
		FETCH_REPORT = 4,
	}
}
