namespace Kaltura
{
	public sealed class KalturaThumbParamsOutputOrderBy : KalturaStringEnum
	{

		private KalturaThumbParamsOutputOrderBy(string name) : base(name) { }
	}
}
