namespace Kaltura
{
	public sealed class KalturaMediaInfoOrderBy : KalturaStringEnum
	{

		private KalturaMediaInfoOrderBy(string name) : base(name) { }
	}
}
