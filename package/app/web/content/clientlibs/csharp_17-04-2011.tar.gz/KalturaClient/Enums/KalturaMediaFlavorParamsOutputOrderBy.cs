namespace Kaltura
{
	public sealed class KalturaMediaFlavorParamsOutputOrderBy : KalturaStringEnum
	{

		private KalturaMediaFlavorParamsOutputOrderBy(string name) : base(name) { }
	}
}
