namespace Kaltura
{
	public sealed class KalturaVirusScanEngineType : KalturaStringEnum
	{
		public static readonly KalturaVirusScanEngineType SYMANTEC_SCAN_ENGINE = new KalturaVirusScanEngineType("symantecScanEngine.SymantecScanEngine");

		private KalturaVirusScanEngineType(string name) : base(name) { }
	}
}
