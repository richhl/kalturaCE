namespace Kaltura
{
	public enum KalturaDistributionProfileStatus
	{
		DISABLED = 1,
		ENABLED = 2,
		DELETED = 3,
	}
}
