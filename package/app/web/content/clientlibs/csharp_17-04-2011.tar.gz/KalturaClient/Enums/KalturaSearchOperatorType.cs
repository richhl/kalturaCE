namespace Kaltura
{
	public enum KalturaSearchOperatorType
	{
		SEARCH_AND = 1,
		SEARCH_OR = 2,
	}
}
