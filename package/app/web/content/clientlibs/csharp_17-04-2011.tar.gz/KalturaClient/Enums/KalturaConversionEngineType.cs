namespace Kaltura
{
	public sealed class KalturaConversionEngineType : KalturaStringEnum
	{
		public static readonly KalturaConversionEngineType KALTURA_COM = new KalturaConversionEngineType("0");
		public static readonly KalturaConversionEngineType ON2 = new KalturaConversionEngineType("1");
		public static readonly KalturaConversionEngineType FFMPEG = new KalturaConversionEngineType("2");
		public static readonly KalturaConversionEngineType MENCODER = new KalturaConversionEngineType("3");
		public static readonly KalturaConversionEngineType ENCODING_COM = new KalturaConversionEngineType("4");
		public static readonly KalturaConversionEngineType EXPRESSION_ENCODER3 = new KalturaConversionEngineType("5");
		public static readonly KalturaConversionEngineType FFMPEG_VP8 = new KalturaConversionEngineType("98");
		public static readonly KalturaConversionEngineType FFMPEG_AUX = new KalturaConversionEngineType("99");
		public static readonly KalturaConversionEngineType PDF2SWF = new KalturaConversionEngineType("201");
		public static readonly KalturaConversionEngineType PDF_CREATOR = new KalturaConversionEngineType("202");
		public static readonly KalturaConversionEngineType QUICK_TIME_PLAYER_TOOLS = new KalturaConversionEngineType("quickTimeTools.QuickTimeTools");
		public static readonly KalturaConversionEngineType FAST_START = new KalturaConversionEngineType("fastStart.FastStart");
		public static readonly KalturaConversionEngineType EXPRESSION_ENCODER = new KalturaConversionEngineType("expressionEncoder.ExpressionEncoder");
		public static readonly KalturaConversionEngineType AVIDEMUX = new KalturaConversionEngineType("avidemux.Avidemux");
		public static readonly KalturaConversionEngineType SEGMENTER = new KalturaConversionEngineType("segmenter.Segmenter");

		private KalturaConversionEngineType(string name) : base(name) { }
	}
}
