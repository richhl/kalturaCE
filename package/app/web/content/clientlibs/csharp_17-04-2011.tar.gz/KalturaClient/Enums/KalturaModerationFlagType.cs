namespace Kaltura
{
	public enum KalturaModerationFlagType
	{
		SEXUAL_CONTENT = 1,
		VIOLENT_REPULSIVE = 2,
		HARMFUL_DANGEROUS = 3,
		SPAM_COMMERCIALS = 4,
	}
}
