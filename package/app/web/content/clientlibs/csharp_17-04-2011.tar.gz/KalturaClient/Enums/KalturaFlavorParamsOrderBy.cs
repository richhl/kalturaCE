namespace Kaltura
{
	public sealed class KalturaFlavorParamsOrderBy : KalturaStringEnum
	{

		private KalturaFlavorParamsOrderBy(string name) : base(name) { }
	}
}
