namespace Kaltura
{
	public enum KalturaModerationFlagStatus
	{
		PENDING = 1,
		MODERATED = 2,
	}
}
