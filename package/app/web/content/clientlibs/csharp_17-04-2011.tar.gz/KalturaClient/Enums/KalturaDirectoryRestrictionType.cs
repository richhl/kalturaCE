namespace Kaltura
{
	public enum KalturaDirectoryRestrictionType
	{
		DONT_DISPLAY = 0,
		DISPLAY_WITH_LINK = 1,
	}
}
