namespace Kaltura
{
	public enum KalturaDistributionProtocol
	{
		FTP = 1,
		SCP = 2,
		SFTP = 3,
		HTTP = 4,
		HTTPS = 5,
	}
}
