namespace Kaltura
{
	public enum KalturaGender
	{
		UNKNOWN = 0,
		MALE = 1,
		FEMALE = 2,
	}
}
