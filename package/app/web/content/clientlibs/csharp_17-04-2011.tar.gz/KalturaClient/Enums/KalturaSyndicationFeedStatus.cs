namespace Kaltura
{
	public enum KalturaSyndicationFeedStatus
	{
		DELETED = -1,
		ACTIVE = 1,
	}
}
