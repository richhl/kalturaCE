namespace Kaltura
{
	public enum KalturaEditorType
	{
		SIMPLE = 1,
		ADVANCED = 2,
	}
}
