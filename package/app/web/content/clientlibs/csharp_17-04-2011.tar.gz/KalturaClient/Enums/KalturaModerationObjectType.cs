namespace Kaltura
{
	public enum KalturaModerationObjectType
	{
		ENTRY = 2,
		USER = 3,
	}
}
