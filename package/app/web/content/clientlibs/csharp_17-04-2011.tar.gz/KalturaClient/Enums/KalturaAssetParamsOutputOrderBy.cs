namespace Kaltura
{
	public sealed class KalturaAssetParamsOutputOrderBy : KalturaStringEnum
	{

		private KalturaAssetParamsOutputOrderBy(string name) : base(name) { }
	}
}
