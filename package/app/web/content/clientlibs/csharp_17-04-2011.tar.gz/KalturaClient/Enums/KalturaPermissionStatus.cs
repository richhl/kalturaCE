namespace Kaltura
{
	public enum KalturaPermissionStatus
	{
		ACTIVE = 1,
		BLOCKED = 2,
		DELETED = 3,
	}
}
