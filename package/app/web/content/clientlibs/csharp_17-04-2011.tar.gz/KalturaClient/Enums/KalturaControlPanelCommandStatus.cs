namespace Kaltura
{
	public enum KalturaControlPanelCommandStatus
	{
		PENDING = 1,
		HANDLED = 2,
		DONE = 3,
		FAILED = 4,
	}
}
