namespace Kaltura
{
	public sealed class KalturaLiveStreamAdminEntryOrderBy : KalturaStringEnum
	{
		public static readonly KalturaLiveStreamAdminEntryOrderBy MEDIA_TYPE_ASC = new KalturaLiveStreamAdminEntryOrderBy("+mediaType");
		public static readonly KalturaLiveStreamAdminEntryOrderBy MEDIA_TYPE_DESC = new KalturaLiveStreamAdminEntryOrderBy("-mediaType");
		public static readonly KalturaLiveStreamAdminEntryOrderBy PLAYS_ASC = new KalturaLiveStreamAdminEntryOrderBy("+plays");
		public static readonly KalturaLiveStreamAdminEntryOrderBy PLAYS_DESC = new KalturaLiveStreamAdminEntryOrderBy("-plays");
		public static readonly KalturaLiveStreamAdminEntryOrderBy VIEWS_ASC = new KalturaLiveStreamAdminEntryOrderBy("+views");
		public static readonly KalturaLiveStreamAdminEntryOrderBy VIEWS_DESC = new KalturaLiveStreamAdminEntryOrderBy("-views");
		public static readonly KalturaLiveStreamAdminEntryOrderBy DURATION_ASC = new KalturaLiveStreamAdminEntryOrderBy("+duration");
		public static readonly KalturaLiveStreamAdminEntryOrderBy DURATION_DESC = new KalturaLiveStreamAdminEntryOrderBy("-duration");
		public static readonly KalturaLiveStreamAdminEntryOrderBy MS_DURATION_ASC = new KalturaLiveStreamAdminEntryOrderBy("+msDuration");
		public static readonly KalturaLiveStreamAdminEntryOrderBy MS_DURATION_DESC = new KalturaLiveStreamAdminEntryOrderBy("-msDuration");
		public static readonly KalturaLiveStreamAdminEntryOrderBy NAME_ASC = new KalturaLiveStreamAdminEntryOrderBy("+name");
		public static readonly KalturaLiveStreamAdminEntryOrderBy NAME_DESC = new KalturaLiveStreamAdminEntryOrderBy("-name");
		public static readonly KalturaLiveStreamAdminEntryOrderBy MODERATION_COUNT_ASC = new KalturaLiveStreamAdminEntryOrderBy("+moderationCount");
		public static readonly KalturaLiveStreamAdminEntryOrderBy MODERATION_COUNT_DESC = new KalturaLiveStreamAdminEntryOrderBy("-moderationCount");
		public static readonly KalturaLiveStreamAdminEntryOrderBy CREATED_AT_ASC = new KalturaLiveStreamAdminEntryOrderBy("+createdAt");
		public static readonly KalturaLiveStreamAdminEntryOrderBy CREATED_AT_DESC = new KalturaLiveStreamAdminEntryOrderBy("-createdAt");
		public static readonly KalturaLiveStreamAdminEntryOrderBy UPDATED_AT_ASC = new KalturaLiveStreamAdminEntryOrderBy("+updatedAt");
		public static readonly KalturaLiveStreamAdminEntryOrderBy UPDATED_AT_DESC = new KalturaLiveStreamAdminEntryOrderBy("-updatedAt");
		public static readonly KalturaLiveStreamAdminEntryOrderBy RANK_ASC = new KalturaLiveStreamAdminEntryOrderBy("+rank");
		public static readonly KalturaLiveStreamAdminEntryOrderBy RANK_DESC = new KalturaLiveStreamAdminEntryOrderBy("-rank");

		private KalturaLiveStreamAdminEntryOrderBy(string name) : base(name) { }
	}
}
