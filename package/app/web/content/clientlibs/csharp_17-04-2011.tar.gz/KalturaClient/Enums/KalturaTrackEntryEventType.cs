namespace Kaltura
{
	public enum KalturaTrackEntryEventType
	{
		UPLOADED_FILE = 1,
		WEBCAM_COMPLETED = 2,
		IMPORT_STARTED = 3,
		ADD_ENTRY = 4,
		UPDATE_ENTRY = 5,
		DELETED_ENTRY = 6,
	}
}
