namespace Kaltura
{
	public sealed class KalturaFlavorParamsOutputOrderBy : KalturaStringEnum
	{

		private KalturaFlavorParamsOutputOrderBy(string name) : base(name) { }
	}
}
