namespace Kaltura
{
	public enum KalturaSessionType
	{
		USER = 0,
		ADMIN = 2,
	}
}
