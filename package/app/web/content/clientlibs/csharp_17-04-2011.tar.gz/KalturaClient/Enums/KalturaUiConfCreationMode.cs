namespace Kaltura
{
	public enum KalturaUiConfCreationMode
	{
		WIZARD = 2,
		ADVANCED = 3,
	}
}
