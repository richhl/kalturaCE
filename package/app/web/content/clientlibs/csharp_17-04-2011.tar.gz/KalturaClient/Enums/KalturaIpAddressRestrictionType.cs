namespace Kaltura
{
	public enum KalturaIpAddressRestrictionType
	{
		RESTRICT_LIST = 0,
		ALLOW_LIST = 1,
	}
}
