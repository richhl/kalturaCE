using System;
using System.Text;
using System.Xml;
using System.Runtime.Serialization;

namespace Kaltura
{
	public static class KalturaObjectFactory
	{
		public static object Create(XmlElement xmlElement)
		{
			switch (xmlElement["objectType"].InnerText)
			{
				case "KalturaBaseRestriction":
					return new KalturaBaseRestriction(xmlElement);
				case "KalturaAccessControl":
					return new KalturaAccessControl(xmlElement);
				case "KalturaSearchItem":
					return new KalturaSearchItem(xmlElement);
				case "KalturaFilter":
					return new KalturaFilter(xmlElement);
				case "KalturaAccessControlBaseFilter":
					return new KalturaAccessControlBaseFilter(xmlElement);
				case "KalturaAccessControlFilter":
					return new KalturaAccessControlFilter(xmlElement);
				case "KalturaFilterPager":
					return new KalturaFilterPager(xmlElement);
				case "KalturaAccessControlListResponse":
					return new KalturaAccessControlListResponse(xmlElement);
				case "KalturaUser":
					return new KalturaUser(xmlElement);
				case "KalturaDynamicEnum":
					return new KalturaDynamicEnum(xmlElement);
				case "KalturaBaseEntry":
					return new KalturaBaseEntry(xmlElement);
				case "KalturaBaseEntryBaseFilter":
					return new KalturaBaseEntryBaseFilter(xmlElement);
				case "KalturaBaseEntryFilter":
					return new KalturaBaseEntryFilter(xmlElement);
				case "KalturaBaseEntryListResponse":
					return new KalturaBaseEntryListResponse(xmlElement);
				case "KalturaModerationFlag":
					return new KalturaModerationFlag(xmlElement);
				case "KalturaModerationFlagListResponse":
					return new KalturaModerationFlagListResponse(xmlElement);
				case "KalturaEntryContextDataParams":
					return new KalturaEntryContextDataParams(xmlElement);
				case "KalturaEntryContextDataResult":
					return new KalturaEntryContextDataResult(xmlElement);
				case "KalturaBulkUploadPluginData":
					return new KalturaBulkUploadPluginData(xmlElement);
				case "KalturaBulkUploadResult":
					return new KalturaBulkUploadResult(xmlElement);
				case "KalturaBulkUpload":
					return new KalturaBulkUpload(xmlElement);
				case "KalturaBulkUploadListResponse":
					return new KalturaBulkUploadListResponse(xmlElement);
				case "KalturaCategory":
					return new KalturaCategory(xmlElement);
				case "KalturaCategoryBaseFilter":
					return new KalturaCategoryBaseFilter(xmlElement);
				case "KalturaCategoryFilter":
					return new KalturaCategoryFilter(xmlElement);
				case "KalturaCategoryListResponse":
					return new KalturaCategoryListResponse(xmlElement);
				case "KalturaCropDimensions":
					return new KalturaCropDimensions(xmlElement);
				case "KalturaConversionProfile":
					return new KalturaConversionProfile(xmlElement);
				case "KalturaConversionProfileBaseFilter":
					return new KalturaConversionProfileBaseFilter(xmlElement);
				case "KalturaConversionProfileFilter":
					return new KalturaConversionProfileFilter(xmlElement);
				case "KalturaConversionProfileListResponse":
					return new KalturaConversionProfileListResponse(xmlElement);
				case "KalturaDataEntry":
					return new KalturaDataEntry(xmlElement);
				case "KalturaDataEntryBaseFilter":
					return new KalturaDataEntryBaseFilter(xmlElement);
				case "KalturaDataEntryFilter":
					return new KalturaDataEntryFilter(xmlElement);
				case "KalturaDataListResponse":
					return new KalturaDataListResponse(xmlElement);
				case "KalturaDocumentEntry":
					return new KalturaDocumentEntry(xmlElement);
				case "KalturaConversionAttribute":
					return new KalturaConversionAttribute(xmlElement);
				case "KalturaDocumentEntryBaseFilter":
					return new KalturaDocumentEntryBaseFilter(xmlElement);
				case "KalturaDocumentEntryFilter":
					return new KalturaDocumentEntryFilter(xmlElement);
				case "KalturaDocumentListResponse":
					return new KalturaDocumentListResponse(xmlElement);
				case "KalturaEmailIngestionProfile":
					return new KalturaEmailIngestionProfile(xmlElement);
				case "KalturaPlayableEntry":
					return new KalturaPlayableEntry(xmlElement);
				case "KalturaMediaEntry":
					return new KalturaMediaEntry(xmlElement);
				case "KalturaAsset":
					return new KalturaAsset(xmlElement);
				case "KalturaFlavorAsset":
					return new KalturaFlavorAsset(xmlElement);
				case "KalturaAssetBaseFilter":
					return new KalturaAssetBaseFilter(xmlElement);
				case "KalturaAssetFilter":
					return new KalturaAssetFilter(xmlElement);
				case "KalturaFlavorAssetListResponse":
					return new KalturaFlavorAssetListResponse(xmlElement);
				case "KalturaString":
					return new KalturaString(xmlElement);
				case "KalturaAssetParams":
					return new KalturaAssetParams(xmlElement);
				case "KalturaFlavorParams":
					return new KalturaFlavorParams(xmlElement);
				case "KalturaFlavorAssetWithParams":
					return new KalturaFlavorAssetWithParams(xmlElement);
				case "KalturaAssetParamsBaseFilter":
					return new KalturaAssetParamsBaseFilter(xmlElement);
				case "KalturaAssetParamsFilter":
					return new KalturaAssetParamsFilter(xmlElement);
				case "KalturaFlavorParamsBaseFilter":
					return new KalturaFlavorParamsBaseFilter(xmlElement);
				case "KalturaFlavorParamsFilter":
					return new KalturaFlavorParamsFilter(xmlElement);
				case "KalturaFlavorParamsListResponse":
					return new KalturaFlavorParamsListResponse(xmlElement);
				case "KalturaLiveStreamBitrate":
					return new KalturaLiveStreamBitrate(xmlElement);
				case "KalturaLiveStreamEntry":
					return new KalturaLiveStreamEntry(xmlElement);
				case "KalturaLiveStreamAdminEntry":
					return new KalturaLiveStreamAdminEntry(xmlElement);
				case "KalturaPlayableEntryBaseFilter":
					return new KalturaPlayableEntryBaseFilter(xmlElement);
				case "KalturaPlayableEntryFilter":
					return new KalturaPlayableEntryFilter(xmlElement);
				case "KalturaMediaEntryBaseFilter":
					return new KalturaMediaEntryBaseFilter(xmlElement);
				case "KalturaMediaEntryFilter":
					return new KalturaMediaEntryFilter(xmlElement);
				case "KalturaLiveStreamEntryBaseFilter":
					return new KalturaLiveStreamEntryBaseFilter(xmlElement);
				case "KalturaLiveStreamEntryFilter":
					return new KalturaLiveStreamEntryFilter(xmlElement);
				case "KalturaLiveStreamListResponse":
					return new KalturaLiveStreamListResponse(xmlElement);
				case "KalturaSearch":
					return new KalturaSearch(xmlElement);
				case "KalturaSearchResult":
					return new KalturaSearchResult(xmlElement);
				case "KalturaMediaListResponse":
					return new KalturaMediaListResponse(xmlElement);
				case "KalturaMixEntry":
					return new KalturaMixEntry(xmlElement);
				case "KalturaMixEntryBaseFilter":
					return new KalturaMixEntryBaseFilter(xmlElement);
				case "KalturaMixEntryFilter":
					return new KalturaMixEntryFilter(xmlElement);
				case "KalturaMixListResponse":
					return new KalturaMixListResponse(xmlElement);
				case "KalturaClientNotification":
					return new KalturaClientNotification(xmlElement);
				case "KalturaKeyValue":
					return new KalturaKeyValue(xmlElement);
				case "KalturaPartner":
					return new KalturaPartner(xmlElement);
				case "KalturaPartnerUsage":
					return new KalturaPartnerUsage(xmlElement);
				case "KalturaPermissionItem":
					return new KalturaPermissionItem(xmlElement);
				case "KalturaPermissionItemBaseFilter":
					return new KalturaPermissionItemBaseFilter(xmlElement);
				case "KalturaPermissionItemFilter":
					return new KalturaPermissionItemFilter(xmlElement);
				case "KalturaPermissionItemListResponse":
					return new KalturaPermissionItemListResponse(xmlElement);
				case "KalturaPermission":
					return new KalturaPermission(xmlElement);
				case "KalturaPermissionBaseFilter":
					return new KalturaPermissionBaseFilter(xmlElement);
				case "KalturaPermissionFilter":
					return new KalturaPermissionFilter(xmlElement);
				case "KalturaPermissionListResponse":
					return new KalturaPermissionListResponse(xmlElement);
				case "KalturaMediaEntryFilterForPlaylist":
					return new KalturaMediaEntryFilterForPlaylist(xmlElement);
				case "KalturaPlaylist":
					return new KalturaPlaylist(xmlElement);
				case "KalturaPlaylistBaseFilter":
					return new KalturaPlaylistBaseFilter(xmlElement);
				case "KalturaPlaylistFilter":
					return new KalturaPlaylistFilter(xmlElement);
				case "KalturaPlaylistListResponse":
					return new KalturaPlaylistListResponse(xmlElement);
				case "KalturaReportInputFilter":
					return new KalturaReportInputFilter(xmlElement);
				case "KalturaReportGraph":
					return new KalturaReportGraph(xmlElement);
				case "KalturaReportTotal":
					return new KalturaReportTotal(xmlElement);
				case "KalturaReportTable":
					return new KalturaReportTable(xmlElement);
				case "KalturaSearchResultResponse":
					return new KalturaSearchResultResponse(xmlElement);
				case "KalturaSearchAuthData":
					return new KalturaSearchAuthData(xmlElement);
				case "KalturaStartWidgetSessionResponse":
					return new KalturaStartWidgetSessionResponse(xmlElement);
				case "KalturaStatsEvent":
					return new KalturaStatsEvent(xmlElement);
				case "KalturaStatsKmcEvent":
					return new KalturaStatsKmcEvent(xmlElement);
				case "KalturaCEError":
					return new KalturaCEError(xmlElement);
				case "KalturaBaseSyndicationFeed":
					return new KalturaBaseSyndicationFeed(xmlElement);
				case "KalturaBaseSyndicationFeedBaseFilter":
					return new KalturaBaseSyndicationFeedBaseFilter(xmlElement);
				case "KalturaBaseSyndicationFeedFilter":
					return new KalturaBaseSyndicationFeedFilter(xmlElement);
				case "KalturaBaseSyndicationFeedListResponse":
					return new KalturaBaseSyndicationFeedListResponse(xmlElement);
				case "KalturaSyndicationFeedEntryCount":
					return new KalturaSyndicationFeedEntryCount(xmlElement);
				case "KalturaThumbAsset":
					return new KalturaThumbAsset(xmlElement);
				case "KalturaThumbParams":
					return new KalturaThumbParams(xmlElement);
				case "KalturaThumbAssetListResponse":
					return new KalturaThumbAssetListResponse(xmlElement);
				case "KalturaThumbParamsBaseFilter":
					return new KalturaThumbParamsBaseFilter(xmlElement);
				case "KalturaThumbParamsFilter":
					return new KalturaThumbParamsFilter(xmlElement);
				case "KalturaThumbParamsListResponse":
					return new KalturaThumbParamsListResponse(xmlElement);
				case "KalturaUiConf":
					return new KalturaUiConf(xmlElement);
				case "KalturaUiConfBaseFilter":
					return new KalturaUiConfBaseFilter(xmlElement);
				case "KalturaUiConfFilter":
					return new KalturaUiConfFilter(xmlElement);
				case "KalturaUiConfListResponse":
					return new KalturaUiConfListResponse(xmlElement);
				case "KalturaUiConfTypeInfo":
					return new KalturaUiConfTypeInfo(xmlElement);
				case "KalturaUploadResponse":
					return new KalturaUploadResponse(xmlElement);
				case "KalturaUploadToken":
					return new KalturaUploadToken(xmlElement);
				case "KalturaUploadTokenBaseFilter":
					return new KalturaUploadTokenBaseFilter(xmlElement);
				case "KalturaUploadTokenFilter":
					return new KalturaUploadTokenFilter(xmlElement);
				case "KalturaUploadTokenListResponse":
					return new KalturaUploadTokenListResponse(xmlElement);
				case "KalturaUserRole":
					return new KalturaUserRole(xmlElement);
				case "KalturaUserRoleBaseFilter":
					return new KalturaUserRoleBaseFilter(xmlElement);
				case "KalturaUserRoleFilter":
					return new KalturaUserRoleFilter(xmlElement);
				case "KalturaUserRoleListResponse":
					return new KalturaUserRoleListResponse(xmlElement);
				case "KalturaUserBaseFilter":
					return new KalturaUserBaseFilter(xmlElement);
				case "KalturaUserFilter":
					return new KalturaUserFilter(xmlElement);
				case "KalturaUserListResponse":
					return new KalturaUserListResponse(xmlElement);
				case "KalturaWidget":
					return new KalturaWidget(xmlElement);
				case "KalturaWidgetBaseFilter":
					return new KalturaWidgetBaseFilter(xmlElement);
				case "KalturaWidgetFilter":
					return new KalturaWidgetFilter(xmlElement);
				case "KalturaWidgetListResponse":
					return new KalturaWidgetListResponse(xmlElement);
				case "KalturaMetadataBaseFilter":
					return new KalturaMetadataBaseFilter(xmlElement);
				case "KalturaMetadataFilter":
					return new KalturaMetadataFilter(xmlElement);
				case "KalturaMetadata":
					return new KalturaMetadata(xmlElement);
				case "KalturaMetadataListResponse":
					return new KalturaMetadataListResponse(xmlElement);
				case "KalturaMetadataProfileBaseFilter":
					return new KalturaMetadataProfileBaseFilter(xmlElement);
				case "KalturaMetadataProfileFilter":
					return new KalturaMetadataProfileFilter(xmlElement);
				case "KalturaMetadataProfile":
					return new KalturaMetadataProfile(xmlElement);
				case "KalturaMetadataProfileListResponse":
					return new KalturaMetadataProfileListResponse(xmlElement);
				case "KalturaMetadataProfileField":
					return new KalturaMetadataProfileField(xmlElement);
				case "KalturaMetadataProfileFieldListResponse":
					return new KalturaMetadataProfileFieldListResponse(xmlElement);
				case "KalturaPartnerBaseFilter":
					return new KalturaPartnerBaseFilter(xmlElement);
				case "KalturaPartnerFilter":
					return new KalturaPartnerFilter(xmlElement);
				case "KalturaStorageProfile":
					return new KalturaStorageProfile(xmlElement);
				case "KalturaStorageProfileListResponse":
					return new KalturaStorageProfileListResponse(xmlElement);
				case "KalturaSystemPartnerUsageFilter":
					return new KalturaSystemPartnerUsageFilter(xmlElement);
				case "KalturaSystemPartnerUsageItem":
					return new KalturaSystemPartnerUsageItem(xmlElement);
				case "KalturaSystemPartnerUsageListResponse":
					return new KalturaSystemPartnerUsageListResponse(xmlElement);
				case "KalturaPartnerListResponse":
					return new KalturaPartnerListResponse(xmlElement);
				case "KalturaSystemPartnerConfiguration":
					return new KalturaSystemPartnerConfiguration(xmlElement);
				case "KalturaSystemPartnerPackage":
					return new KalturaSystemPartnerPackage(xmlElement);
				case "KalturaFlavorParamsOutputBaseFilter":
					return new KalturaFlavorParamsOutputBaseFilter(xmlElement);
				case "KalturaFlavorParamsOutputFilter":
					return new KalturaFlavorParamsOutputFilter(xmlElement);
				case "KalturaFlavorParamsOutput":
					return new KalturaFlavorParamsOutput(xmlElement);
				case "KalturaFlavorParamsOutputListResponse":
					return new KalturaFlavorParamsOutputListResponse(xmlElement);
				case "KalturaThumbParamsOutputBaseFilter":
					return new KalturaThumbParamsOutputBaseFilter(xmlElement);
				case "KalturaThumbParamsOutputFilter":
					return new KalturaThumbParamsOutputFilter(xmlElement);
				case "KalturaThumbParamsOutput":
					return new KalturaThumbParamsOutput(xmlElement);
				case "KalturaThumbParamsOutputListResponse":
					return new KalturaThumbParamsOutputListResponse(xmlElement);
				case "KalturaMediaInfoBaseFilter":
					return new KalturaMediaInfoBaseFilter(xmlElement);
				case "KalturaMediaInfoFilter":
					return new KalturaMediaInfoFilter(xmlElement);
				case "KalturaMediaInfo":
					return new KalturaMediaInfo(xmlElement);
				case "KalturaMediaInfoListResponse":
					return new KalturaMediaInfoListResponse(xmlElement);
				case "KalturaTrackEntry":
					return new KalturaTrackEntry(xmlElement);
				case "KalturaTrackEntryListResponse":
					return new KalturaTrackEntryListResponse(xmlElement);
				case "KalturaUiConfAdmin":
					return new KalturaUiConfAdmin(xmlElement);
				case "KalturaUiConfAdminListResponse":
					return new KalturaUiConfAdminListResponse(xmlElement);
				case "KalturaInternalToolsSession":
					return new KalturaInternalToolsSession(xmlElement);
				case "KalturaAuditTrailBaseFilter":
					return new KalturaAuditTrailBaseFilter(xmlElement);
				case "KalturaAuditTrailFilter":
					return new KalturaAuditTrailFilter(xmlElement);
				case "KalturaAuditTrailInfo":
					return new KalturaAuditTrailInfo(xmlElement);
				case "KalturaAuditTrail":
					return new KalturaAuditTrail(xmlElement);
				case "KalturaAuditTrailListResponse":
					return new KalturaAuditTrailListResponse(xmlElement);
				case "KalturaVirusScanProfileBaseFilter":
					return new KalturaVirusScanProfileBaseFilter(xmlElement);
				case "KalturaVirusScanProfileFilter":
					return new KalturaVirusScanProfileFilter(xmlElement);
				case "KalturaVirusScanProfile":
					return new KalturaVirusScanProfile(xmlElement);
				case "KalturaVirusScanProfileListResponse":
					return new KalturaVirusScanProfileListResponse(xmlElement);
				case "KalturaDistributionThumbDimensions":
					return new KalturaDistributionThumbDimensions(xmlElement);
				case "KalturaDistributionProfile":
					return new KalturaDistributionProfile(xmlElement);
				case "KalturaDistributionProfileBaseFilter":
					return new KalturaDistributionProfileBaseFilter(xmlElement);
				case "KalturaDistributionProfileFilter":
					return new KalturaDistributionProfileFilter(xmlElement);
				case "KalturaDistributionProfileListResponse":
					return new KalturaDistributionProfileListResponse(xmlElement);
				case "KalturaDistributionValidationError":
					return new KalturaDistributionValidationError(xmlElement);
				case "KalturaEntryDistribution":
					return new KalturaEntryDistribution(xmlElement);
				case "KalturaEntryDistributionBaseFilter":
					return new KalturaEntryDistributionBaseFilter(xmlElement);
				case "KalturaEntryDistributionFilter":
					return new KalturaEntryDistributionFilter(xmlElement);
				case "KalturaEntryDistributionListResponse":
					return new KalturaEntryDistributionListResponse(xmlElement);
				case "KalturaDistributionProviderBaseFilter":
					return new KalturaDistributionProviderBaseFilter(xmlElement);
				case "KalturaDistributionProviderFilter":
					return new KalturaDistributionProviderFilter(xmlElement);
				case "KalturaDistributionProvider":
					return new KalturaDistributionProvider(xmlElement);
				case "KalturaDistributionProviderListResponse":
					return new KalturaDistributionProviderListResponse(xmlElement);
				case "KalturaGenericDistributionProvider":
					return new KalturaGenericDistributionProvider(xmlElement);
				case "KalturaGenericDistributionProviderBaseFilter":
					return new KalturaGenericDistributionProviderBaseFilter(xmlElement);
				case "KalturaGenericDistributionProviderFilter":
					return new KalturaGenericDistributionProviderFilter(xmlElement);
				case "KalturaGenericDistributionProviderListResponse":
					return new KalturaGenericDistributionProviderListResponse(xmlElement);
				case "KalturaGenericDistributionProviderAction":
					return new KalturaGenericDistributionProviderAction(xmlElement);
				case "KalturaGenericDistributionProviderActionBaseFilter":
					return new KalturaGenericDistributionProviderActionBaseFilter(xmlElement);
				case "KalturaGenericDistributionProviderActionFilter":
					return new KalturaGenericDistributionProviderActionFilter(xmlElement);
				case "KalturaGenericDistributionProviderActionListResponse":
					return new KalturaGenericDistributionProviderActionListResponse(xmlElement);
				case "KalturaAnnotationBaseFilter":
					return new KalturaAnnotationBaseFilter(xmlElement);
				case "KalturaAnnotationFilter":
					return new KalturaAnnotationFilter(xmlElement);
				case "KalturaAnnotation":
					return new KalturaAnnotation(xmlElement);
				case "KalturaAnnotationListResponse":
					return new KalturaAnnotationListResponse(xmlElement);
				case "KalturaShortLinkBaseFilter":
					return new KalturaShortLinkBaseFilter(xmlElement);
				case "KalturaShortLinkFilter":
					return new KalturaShortLinkFilter(xmlElement);
				case "KalturaShortLink":
					return new KalturaShortLink(xmlElement);
				case "KalturaShortLinkListResponse":
					return new KalturaShortLinkListResponse(xmlElement);
				case "KalturaCountryRestriction":
					return new KalturaCountryRestriction(xmlElement);
				case "KalturaDirectoryRestriction":
					return new KalturaDirectoryRestriction(xmlElement);
				case "KalturaIpAddressRestriction":
					return new KalturaIpAddressRestriction(xmlElement);
				case "KalturaSessionRestriction":
					return new KalturaSessionRestriction(xmlElement);
				case "KalturaPreviewRestriction":
					return new KalturaPreviewRestriction(xmlElement);
				case "KalturaSiteRestriction":
					return new KalturaSiteRestriction(xmlElement);
				case "KalturaSearchCondition":
					return new KalturaSearchCondition(xmlElement);
				case "KalturaSearchComparableCondition":
					return new KalturaSearchComparableCondition(xmlElement);
				case "KalturaSearchOperator":
					return new KalturaSearchOperator(xmlElement);
				case "KalturaBaseJobBaseFilter":
					return new KalturaBaseJobBaseFilter(xmlElement);
				case "KalturaBaseJobFilter":
					return new KalturaBaseJobFilter(xmlElement);
				case "KalturaBatchJobBaseFilter":
					return new KalturaBatchJobBaseFilter(xmlElement);
				case "KalturaControlPanelCommandBaseFilter":
					return new KalturaControlPanelCommandBaseFilter(xmlElement);
				case "KalturaMailJobBaseFilter":
					return new KalturaMailJobBaseFilter(xmlElement);
				case "KalturaNotificationBaseFilter":
					return new KalturaNotificationBaseFilter(xmlElement);
				case "KalturaBatchJobFilter":
					return new KalturaBatchJobFilter(xmlElement);
				case "KalturaControlPanelCommandFilter":
					return new KalturaControlPanelCommandFilter(xmlElement);
				case "KalturaMailJobFilter":
					return new KalturaMailJobFilter(xmlElement);
				case "KalturaNotificationFilter":
					return new KalturaNotificationFilter(xmlElement);
				case "KalturaBatchJobFilterExt":
					return new KalturaBatchJobFilterExt(xmlElement);
				case "KalturaAssetParamsOutputBaseFilter":
					return new KalturaAssetParamsOutputBaseFilter(xmlElement);
				case "KalturaFlavorAssetBaseFilter":
					return new KalturaFlavorAssetBaseFilter(xmlElement);
				case "KalturaMediaFlavorParamsBaseFilter":
					return new KalturaMediaFlavorParamsBaseFilter(xmlElement);
				case "KalturaMediaFlavorParamsOutputBaseFilter":
					return new KalturaMediaFlavorParamsOutputBaseFilter(xmlElement);
				case "KalturaThumbAssetBaseFilter":
					return new KalturaThumbAssetBaseFilter(xmlElement);
				case "KalturaAssetParamsOutputFilter":
					return new KalturaAssetParamsOutputFilter(xmlElement);
				case "KalturaFlavorAssetFilter":
					return new KalturaFlavorAssetFilter(xmlElement);
				case "KalturaMediaFlavorParamsFilter":
					return new KalturaMediaFlavorParamsFilter(xmlElement);
				case "KalturaMediaFlavorParamsOutputFilter":
					return new KalturaMediaFlavorParamsOutputFilter(xmlElement);
				case "KalturaThumbAssetFilter":
					return new KalturaThumbAssetFilter(xmlElement);
				case "KalturaLiveStreamAdminEntryBaseFilter":
					return new KalturaLiveStreamAdminEntryBaseFilter(xmlElement);
				case "KalturaLiveStreamAdminEntryFilter":
					return new KalturaLiveStreamAdminEntryFilter(xmlElement);
				case "KalturaAdminUserBaseFilter":
					return new KalturaAdminUserBaseFilter(xmlElement);
				case "KalturaAdminUserFilter":
					return new KalturaAdminUserFilter(xmlElement);
				case "KalturaGoogleVideoSyndicationFeedBaseFilter":
					return new KalturaGoogleVideoSyndicationFeedBaseFilter(xmlElement);
				case "KalturaGoogleVideoSyndicationFeedFilter":
					return new KalturaGoogleVideoSyndicationFeedFilter(xmlElement);
				case "KalturaITunesSyndicationFeedBaseFilter":
					return new KalturaITunesSyndicationFeedBaseFilter(xmlElement);
				case "KalturaITunesSyndicationFeedFilter":
					return new KalturaITunesSyndicationFeedFilter(xmlElement);
				case "KalturaTubeMogulSyndicationFeedBaseFilter":
					return new KalturaTubeMogulSyndicationFeedBaseFilter(xmlElement);
				case "KalturaTubeMogulSyndicationFeedFilter":
					return new KalturaTubeMogulSyndicationFeedFilter(xmlElement);
				case "KalturaYahooSyndicationFeedBaseFilter":
					return new KalturaYahooSyndicationFeedBaseFilter(xmlElement);
				case "KalturaYahooSyndicationFeedFilter":
					return new KalturaYahooSyndicationFeedFilter(xmlElement);
				case "KalturaApiActionPermissionItemBaseFilter":
					return new KalturaApiActionPermissionItemBaseFilter(xmlElement);
				case "KalturaApiParameterPermissionItemBaseFilter":
					return new KalturaApiParameterPermissionItemBaseFilter(xmlElement);
				case "KalturaApiActionPermissionItemFilter":
					return new KalturaApiActionPermissionItemFilter(xmlElement);
				case "KalturaApiParameterPermissionItemFilter":
					return new KalturaApiParameterPermissionItemFilter(xmlElement);
				case "KalturaGenericSyndicationFeedBaseFilter":
					return new KalturaGenericSyndicationFeedBaseFilter(xmlElement);
				case "KalturaGenericSyndicationFeedFilter":
					return new KalturaGenericSyndicationFeedFilter(xmlElement);
				case "KalturaGenericXsltSyndicationFeedBaseFilter":
					return new KalturaGenericXsltSyndicationFeedBaseFilter(xmlElement);
				case "KalturaGenericXsltSyndicationFeedFilter":
					return new KalturaGenericXsltSyndicationFeedFilter(xmlElement);
				case "KalturaAssetParamsOutput":
					return new KalturaAssetParamsOutput(xmlElement);
				case "KalturaMediaFlavorParamsOutput":
					return new KalturaMediaFlavorParamsOutput(xmlElement);
				case "KalturaMediaFlavorParams":
					return new KalturaMediaFlavorParams(xmlElement);
				case "KalturaApiActionPermissionItem":
					return new KalturaApiActionPermissionItem(xmlElement);
				case "KalturaApiParameterPermissionItem":
					return new KalturaApiParameterPermissionItem(xmlElement);
				case "KalturaGenericSyndicationFeed":
					return new KalturaGenericSyndicationFeed(xmlElement);
				case "KalturaGenericXsltSyndicationFeed":
					return new KalturaGenericXsltSyndicationFeed(xmlElement);
				case "KalturaGoogleVideoSyndicationFeed":
					return new KalturaGoogleVideoSyndicationFeed(xmlElement);
				case "KalturaITunesSyndicationFeed":
					return new KalturaITunesSyndicationFeed(xmlElement);
				case "KalturaTubeMogulSyndicationFeed":
					return new KalturaTubeMogulSyndicationFeed(xmlElement);
				case "KalturaYahooSyndicationFeed":
					return new KalturaYahooSyndicationFeed(xmlElement);
			}
			throw new SerializationException("Invalid object type");
		}
	}
}
