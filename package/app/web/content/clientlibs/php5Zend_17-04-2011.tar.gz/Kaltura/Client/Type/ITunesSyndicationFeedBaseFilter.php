<?php
abstract class Kaltura_Client_Type_ITunesSyndicationFeedBaseFilter extends Kaltura_Client_Type_BaseSyndicationFeedFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaITunesSyndicationFeedBaseFilter';
	}
	

}

