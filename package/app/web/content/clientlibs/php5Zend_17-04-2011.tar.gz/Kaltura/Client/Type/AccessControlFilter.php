<?php
class Kaltura_Client_Type_AccessControlFilter extends Kaltura_Client_Type_AccessControlBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaAccessControlFilter';
	}
	

}

