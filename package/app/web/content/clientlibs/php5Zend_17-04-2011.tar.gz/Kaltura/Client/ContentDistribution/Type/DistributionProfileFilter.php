<?php
class Kaltura_Client_ContentDistribution_Type_DistributionProfileFilter extends Kaltura_Client_ContentDistribution_Type_DistributionProfileBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaDistributionProfileFilter';
	}
	

}

