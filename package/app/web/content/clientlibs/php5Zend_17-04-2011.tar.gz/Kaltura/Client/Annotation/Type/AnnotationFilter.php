<?php
class Kaltura_Client_Annotation_Type_AnnotationFilter extends Kaltura_Client_Annotation_Type_AnnotationBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaAnnotationFilter';
	}
	

}

