<?php
class Kaltura_Client_Type_BatchJobFilter extends Kaltura_Client_Type_BatchJobBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaBatchJobFilter';
	}
	

}

