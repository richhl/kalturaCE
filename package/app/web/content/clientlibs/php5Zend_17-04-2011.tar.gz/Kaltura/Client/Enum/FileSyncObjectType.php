<?php
class Kaltura_Client_Enum_FileSyncObjectType
{
	const ENTRY = "1";
	const UICONF = "2";
	const BATCHJOB = "3";
	const FLAVOR_ASSET = "4";
	const METADATA = "5";
	const METADATA_PROFILE = "6";
	const SYNDICATION_FEED = "7";
	const GENERIC_DISTRIBUTION_ACTION = "contentDistribution.GenericDistributionAction";
	const ENTRY_DISTRIBUTION = "contentDistribution.EntryDistribution";
	const DISTRIBUTION_PROFILE = "contentDistribution.DistributionProfile";
}

