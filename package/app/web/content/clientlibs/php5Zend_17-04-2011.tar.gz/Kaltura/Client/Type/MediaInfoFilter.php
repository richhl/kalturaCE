<?php
class Kaltura_Client_Type_MediaInfoFilter extends Kaltura_Client_Type_MediaInfoBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaMediaInfoFilter';
	}
	

}

