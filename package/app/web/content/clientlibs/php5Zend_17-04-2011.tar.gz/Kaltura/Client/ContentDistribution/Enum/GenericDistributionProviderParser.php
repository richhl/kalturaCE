<?php
class Kaltura_Client_ContentDistribution_Enum_GenericDistributionProviderParser
{
	const XSL = 1;
	const XPATH = 2;
	const REGEX = 3;
}

