<?php
class Kaltura_Client_ShortLink_Type_ShortLinkFilter extends Kaltura_Client_ShortLink_Type_ShortLinkBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaShortLinkFilter';
	}
	

}

