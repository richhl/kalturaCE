<?php
class Kaltura_Client_Type_BaseSyndicationFeedFilter extends Kaltura_Client_Type_BaseSyndicationFeedBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaBaseSyndicationFeedFilter';
	}
	

}

