<?php
class Kaltura_Client_Enum_BitRateMode
{
	const CBR = 1;
	const VBR = 2;
}

