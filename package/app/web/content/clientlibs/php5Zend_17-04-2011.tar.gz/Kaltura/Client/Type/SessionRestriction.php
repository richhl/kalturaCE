<?php
class Kaltura_Client_Type_SessionRestriction extends Kaltura_Client_Type_BaseRestriction
{
	public function getKalturaObjectType()
	{
		return 'KalturaSessionRestriction';
	}
	

}

