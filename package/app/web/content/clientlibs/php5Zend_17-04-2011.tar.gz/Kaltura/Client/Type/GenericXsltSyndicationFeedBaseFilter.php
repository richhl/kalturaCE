<?php
abstract class Kaltura_Client_Type_GenericXsltSyndicationFeedBaseFilter extends Kaltura_Client_Type_GenericSyndicationFeedFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaGenericXsltSyndicationFeedBaseFilter';
	}
	

}

