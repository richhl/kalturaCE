<?php
abstract class Kaltura_Client_Type_BaseSyndicationFeedBaseFilter extends Kaltura_Client_Type_Filter
{
	public function getKalturaObjectType()
	{
		return 'KalturaBaseSyndicationFeedBaseFilter';
	}
	

}

