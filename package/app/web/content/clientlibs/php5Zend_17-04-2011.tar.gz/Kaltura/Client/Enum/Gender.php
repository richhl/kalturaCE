<?php
class Kaltura_Client_Enum_Gender
{
	const UNKNOWN = 0;
	const MALE = 1;
	const FEMALE = 2;
}

