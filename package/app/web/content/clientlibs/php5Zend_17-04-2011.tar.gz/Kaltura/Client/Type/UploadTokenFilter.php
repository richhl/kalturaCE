<?php
class Kaltura_Client_Type_UploadTokenFilter extends Kaltura_Client_Type_UploadTokenBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaUploadTokenFilter';
	}
	

}

