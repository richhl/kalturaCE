<?php
class Kaltura_Client_Type_WidgetFilter extends Kaltura_Client_Type_WidgetBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaWidgetFilter';
	}
	

}

