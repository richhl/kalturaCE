<?php
class Kaltura_Client_Type_MixEntryFilter extends Kaltura_Client_Type_MixEntryBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaMixEntryFilter';
	}
	

}

