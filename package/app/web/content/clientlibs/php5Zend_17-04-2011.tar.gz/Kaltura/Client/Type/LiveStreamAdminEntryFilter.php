<?php
class Kaltura_Client_Type_LiveStreamAdminEntryFilter extends Kaltura_Client_Type_LiveStreamAdminEntryBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaLiveStreamAdminEntryFilter';
	}
	

}

