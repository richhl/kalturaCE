<?php
class Kaltura_Client_Type_ControlPanelCommandFilter extends Kaltura_Client_Type_ControlPanelCommandBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaControlPanelCommandFilter';
	}
	

}

