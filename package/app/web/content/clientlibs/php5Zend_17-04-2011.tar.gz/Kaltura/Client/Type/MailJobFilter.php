<?php
class Kaltura_Client_Type_MailJobFilter extends Kaltura_Client_Type_MailJobBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaMailJobFilter';
	}
	

}

