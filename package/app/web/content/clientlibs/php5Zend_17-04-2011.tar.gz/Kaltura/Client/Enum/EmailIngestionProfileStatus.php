<?php
class Kaltura_Client_Enum_EmailIngestionProfileStatus
{
	const INACTIVE = 0;
	const ACTIVE = 1;
}

