<?php
class Kaltura_Client_Type_AssetParamsFilter extends Kaltura_Client_Type_AssetParamsBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaAssetParamsFilter';
	}
	

}

