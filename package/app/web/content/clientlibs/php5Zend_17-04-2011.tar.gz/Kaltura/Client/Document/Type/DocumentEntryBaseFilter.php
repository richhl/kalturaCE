<?php
abstract class Kaltura_Client_Document_Type_DocumentEntryBaseFilter extends Kaltura_Client_Type_BaseEntryFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaDocumentEntryBaseFilter';
	}
	
	/**
	 * 
	 *
	 * @var Kaltura_Client_Document_Enum_DocumentType
	 */
	public $documentTypeEqual = null;

	/**
	 * 
	 *
	 * @var string
	 */
	public $documentTypeIn = null;


}

