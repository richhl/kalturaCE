<?php
class Kaltura_Client_Enum_SessionType
{
	const USER = 0;
	const ADMIN = 2;
}

