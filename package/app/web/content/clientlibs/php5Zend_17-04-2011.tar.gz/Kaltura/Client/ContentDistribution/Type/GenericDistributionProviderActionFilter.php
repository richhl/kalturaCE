<?php
class Kaltura_Client_ContentDistribution_Type_GenericDistributionProviderActionFilter extends Kaltura_Client_ContentDistribution_Type_GenericDistributionProviderActionBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaGenericDistributionProviderActionFilter';
	}
	

}

