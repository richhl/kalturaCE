<?php
class Kaltura_Client_Type_CountryRestriction extends Kaltura_Client_Type_BaseRestriction
{
	public function getKalturaObjectType()
	{
		return 'KalturaCountryRestriction';
	}
	
	/**
	 * Country restriction type (Allow or deny)
	 * 
	 *
	 * @var Kaltura_Client_Enum_CountryRestrictionType
	 */
	public $countryRestrictionType = null;

	/**
	 * Comma separated list of country codes to allow to deny 
	 * 
	 *
	 * @var string
	 */
	public $countryList = null;


}

