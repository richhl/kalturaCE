<?php
abstract class Kaltura_Client_Type_ApiActionPermissionItemBaseFilter extends Kaltura_Client_Type_PermissionItemFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaApiActionPermissionItemBaseFilter';
	}
	

}

