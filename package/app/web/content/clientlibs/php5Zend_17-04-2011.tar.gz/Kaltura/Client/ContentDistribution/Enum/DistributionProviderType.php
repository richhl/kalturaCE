<?php
class Kaltura_Client_ContentDistribution_Enum_DistributionProviderType
{
	const GENERIC = "1";
	const SYNDICATION = "2";
	const YOUTUBE_API = "youtubeApiDistribution.YOUTUBE_API";
	const DAILYMOTION = "dailymotionDistribution.DAILYMOTION";
	const MSN = "msnDistribution.MSN";
	const VERIZON = "verizonDistribution.VERIZON";
	const COMCAST = "comcastDistribution.COMCAST";
	const YOUTUBE = "youTubeDistribution.YOUTUBE";
}

