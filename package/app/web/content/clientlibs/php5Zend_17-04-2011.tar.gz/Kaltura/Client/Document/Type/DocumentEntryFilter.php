<?php
class Kaltura_Client_Document_Type_DocumentEntryFilter extends Kaltura_Client_Document_Type_DocumentEntryBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaDocumentEntryFilter';
	}
	

}

