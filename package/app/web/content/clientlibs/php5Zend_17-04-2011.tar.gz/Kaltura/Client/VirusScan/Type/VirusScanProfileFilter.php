<?php
class Kaltura_Client_VirusScan_Type_VirusScanProfileFilter extends Kaltura_Client_VirusScan_Type_VirusScanProfileBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaVirusScanProfileFilter';
	}
	

}

