<?php
class Kaltura_Client_Type_AssetParamsOutputFilter extends Kaltura_Client_Type_AssetParamsOutputBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaAssetParamsOutputFilter';
	}
	

}

