<?php
class Kaltura_Client_Type_GenericSyndicationFeedFilter extends Kaltura_Client_Type_GenericSyndicationFeedBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaGenericSyndicationFeedFilter';
	}
	

}

