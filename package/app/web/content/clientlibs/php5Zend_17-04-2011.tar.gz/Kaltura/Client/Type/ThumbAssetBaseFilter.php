<?php
abstract class Kaltura_Client_Type_ThumbAssetBaseFilter extends Kaltura_Client_Type_AssetFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaThumbAssetBaseFilter';
	}
	

}

