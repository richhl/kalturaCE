<?php
class Kaltura_Client_Type_AdminUserFilter extends Kaltura_Client_Type_AdminUserBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaAdminUserFilter';
	}
	

}

