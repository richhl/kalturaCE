<?php
/**
 * Implement to get Kaltura Client logs
 * 
 * @package External
 * @subpackage Kaltura
 */
interface Kaltura_Client_ILogger 
{
	function log($msg); 
}
