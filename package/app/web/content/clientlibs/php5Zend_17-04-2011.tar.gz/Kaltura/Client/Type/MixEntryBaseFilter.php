<?php
abstract class Kaltura_Client_Type_MixEntryBaseFilter extends Kaltura_Client_Type_PlayableEntryFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaMixEntryBaseFilter';
	}
	

}

