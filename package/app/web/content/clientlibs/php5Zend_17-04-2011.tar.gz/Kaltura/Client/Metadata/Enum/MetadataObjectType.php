<?php
class Kaltura_Client_Metadata_Enum_MetadataObjectType
{
	const ENTRY = 1;
}

