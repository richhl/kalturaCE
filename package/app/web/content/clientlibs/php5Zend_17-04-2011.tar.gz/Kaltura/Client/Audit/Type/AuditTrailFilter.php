<?php
class Kaltura_Client_Audit_Type_AuditTrailFilter extends Kaltura_Client_Audit_Type_AuditTrailBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaAuditTrailFilter';
	}
	

}

