<?php
class Kaltura_Client_ContentDistribution_Enum_DistributionProviderOrderBy
{
}

