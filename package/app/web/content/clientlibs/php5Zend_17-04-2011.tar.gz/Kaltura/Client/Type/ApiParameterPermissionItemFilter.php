<?php
class Kaltura_Client_Type_ApiParameterPermissionItemFilter extends Kaltura_Client_Type_ApiParameterPermissionItemBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaApiParameterPermissionItemFilter';
	}
	

}

