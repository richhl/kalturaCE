<?php
class Kaltura_Client_Type_MediaFlavorParamsFilter extends Kaltura_Client_Type_MediaFlavorParamsBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaMediaFlavorParamsFilter';
	}
	

}

