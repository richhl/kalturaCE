<?php
class Kaltura_Client_Type_DataEntryFilter extends Kaltura_Client_Type_DataEntryBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaDataEntryFilter';
	}
	

}

