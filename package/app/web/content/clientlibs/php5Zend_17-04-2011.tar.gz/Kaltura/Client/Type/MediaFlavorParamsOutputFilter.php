<?php
class Kaltura_Client_Type_MediaFlavorParamsOutputFilter extends Kaltura_Client_Type_MediaFlavorParamsOutputBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaMediaFlavorParamsOutputFilter';
	}
	

}

