<?php
abstract class Kaltura_Client_Type_MailJobBaseFilter extends Kaltura_Client_Type_BaseJobFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaMailJobBaseFilter';
	}
	

}

