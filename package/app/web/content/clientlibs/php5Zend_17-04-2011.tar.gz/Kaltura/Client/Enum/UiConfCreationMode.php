<?php
class Kaltura_Client_Enum_UiConfCreationMode
{
	const WIZARD = 2;
	const ADVANCED = 3;
}

