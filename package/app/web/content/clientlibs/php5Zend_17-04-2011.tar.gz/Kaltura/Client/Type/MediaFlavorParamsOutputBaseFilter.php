<?php
abstract class Kaltura_Client_Type_MediaFlavorParamsOutputBaseFilter extends Kaltura_Client_Type_FlavorParamsOutputFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaMediaFlavorParamsOutputBaseFilter';
	}
	

}

