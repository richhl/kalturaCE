<?php
class Kaltura_Client_Type_CategoryFilter extends Kaltura_Client_Type_CategoryBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaCategoryFilter';
	}
	

}

