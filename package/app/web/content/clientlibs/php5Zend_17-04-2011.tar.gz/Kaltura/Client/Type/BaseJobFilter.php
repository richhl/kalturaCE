<?php
class Kaltura_Client_Type_BaseJobFilter extends Kaltura_Client_Type_BaseJobBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaBaseJobFilter';
	}
	

}

