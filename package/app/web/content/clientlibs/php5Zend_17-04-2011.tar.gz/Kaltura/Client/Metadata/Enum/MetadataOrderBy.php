<?php
class Kaltura_Client_Metadata_Enum_MetadataOrderBy
{
	const METADATA_PROFILE_VERSION_ASC = "+metadataProfileVersion";
	const METADATA_PROFILE_VERSION_DESC = "-metadataProfileVersion";
	const VERSION_ASC = "+version";
	const VERSION_DESC = "-version";
	const CREATED_AT_ASC = "+createdAt";
	const CREATED_AT_DESC = "-createdAt";
	const UPDATED_AT_ASC = "+updatedAt";
	const UPDATED_AT_DESC = "-updatedAt";
}

