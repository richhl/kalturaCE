<?php
class Kaltura_Client_Metadata_Enum_MetadataProfileStatus
{
	const ACTIVE = 1;
	const DEPRECATED = 2;
	const TRANSFORMING = 3;
}

