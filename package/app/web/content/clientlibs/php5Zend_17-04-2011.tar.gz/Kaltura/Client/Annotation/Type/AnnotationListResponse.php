<?php
class Kaltura_Client_Annotation_Type_AnnotationListResponse extends Kaltura_Client_ObjectBase
{
	public function getKalturaObjectType()
	{
		return 'KalturaAnnotationListResponse';
	}
	
	/**
	 * 
	 *
	 * @var array of KalturaAnnotation
	 * @readonly
	 */
	public $objects;

	/**
	 * 
	 *
	 * @var int
	 * @readonly
	 */
	public $totalCount = null;


}

