<?php
class Kaltura_Client_Type_DynamicEnum extends Kaltura_Client_ObjectBase
{
	public function getKalturaObjectType()
	{
		return 'KalturaDynamicEnum';
	}
	

}

