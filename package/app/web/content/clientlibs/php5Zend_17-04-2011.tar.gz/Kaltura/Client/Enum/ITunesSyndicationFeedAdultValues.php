<?php
class Kaltura_Client_Enum_ITunesSyndicationFeedAdultValues
{
	const YES = "yes";
	const NO = "no";
	const CLEAN = "clean";
}

