<?php
class Kaltura_Client_Enum_SyndicationFeedStatus
{
	const DELETED = -1;
	const ACTIVE = 1;
}

