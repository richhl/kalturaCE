<?php
class Kaltura_Client_ContentDistribution_Enum_DistributionProfileStatus
{
	const DISABLED = 1;
	const ENABLED = 2;
	const DELETED = 3;
}

