<?php
class Kaltura_Client_Enum_EditorType
{
	const SIMPLE = 1;
	const ADVANCED = 2;
}

