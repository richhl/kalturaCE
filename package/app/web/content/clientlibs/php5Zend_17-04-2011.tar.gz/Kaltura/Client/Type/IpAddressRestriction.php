<?php
class Kaltura_Client_Type_IpAddressRestriction extends Kaltura_Client_Type_BaseRestriction
{
	public function getKalturaObjectType()
	{
		return 'KalturaIpAddressRestriction';
	}
	
	/**
	 * Ip address restriction type (Allow or deny)
	 * 
	 *
	 * @var Kaltura_Client_Enum_IpAddressRestrictionType
	 */
	public $ipAddressRestrictionType = null;

	/**
	 * Comma separated list of ip address to allow to deny 
	 * 
	 *
	 * @var string
	 */
	public $ipAddressList = null;


}

