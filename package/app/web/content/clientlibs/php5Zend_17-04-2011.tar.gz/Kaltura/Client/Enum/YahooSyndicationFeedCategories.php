<?php
class Kaltura_Client_Enum_YahooSyndicationFeedCategories
{
	const ACTION = "Action";
	const ART_AND_ANIMATION = "Art &amp; Animation";
	const ENTERTAINMENT_AND_TV = "Entertainment &amp; TV";
	const FOOD = "Food";
	const GAMES = "Games";
	const HOW_TO = "How-To";
	const MUSIC = "Music";
	const PEOPLE_AND_VLOGS = "People &amp; Vlogs";
	const SCIENCE_AND_ENVIRONMENT = "Science &amp; Environment";
	const TRANSPORTATION = "Transportation";
	const ANIMALS = "Animals";
	const COMMERCIALS = "Commercials";
	const FAMILY = "Family";
	const FUNNY_VIDEOS = "Funny Videos";
	const HEALTH_AND_BEAUTY = "Health &amp; Beauty";
	const MOVIES_AND_SHORTS = "Movies &amp; Shorts";
	const NEWS_AND_POLITICS = "News &amp; Politics";
	const PRODUCTS_AND_TECH = "Products &amp; Tech.";
	const SPORTS = "Sports";
	const TRAVEL = "Travel";
}

