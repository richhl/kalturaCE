<?php
class Kaltura_Client_Type_ThumbParamsOutputFilter extends Kaltura_Client_Type_ThumbParamsOutputBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaThumbParamsOutputFilter';
	}
	

}

