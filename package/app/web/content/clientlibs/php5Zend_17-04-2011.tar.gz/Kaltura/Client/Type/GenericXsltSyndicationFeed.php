<?php
class Kaltura_Client_Type_GenericXsltSyndicationFeed extends Kaltura_Client_Type_GenericSyndicationFeed
{
	public function getKalturaObjectType()
	{
		return 'KalturaGenericXsltSyndicationFeed';
	}
	
	/**
	 * 
	 *
	 * @var string
	 */
	public $xslt = null;


}

