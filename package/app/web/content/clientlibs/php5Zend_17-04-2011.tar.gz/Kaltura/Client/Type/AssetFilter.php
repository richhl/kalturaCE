<?php
class Kaltura_Client_Type_AssetFilter extends Kaltura_Client_Type_AssetBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaAssetFilter';
	}
	

}

