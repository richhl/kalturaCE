<?php
class Kaltura_Client_Type_PartnerFilter extends Kaltura_Client_Type_PartnerBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaPartnerFilter';
	}
	

}

