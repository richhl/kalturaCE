<?php
/**
 * @package External
 * @subpackage Kaltura
 */
class Kaltura_Client_Exception extends Exception 
{
    public function __construct($message, $code) 
    {
    	$this->code = $code;
		parent::__construct($message);
    }
}
