<?php
class Kaltura_Client_ContentDistribution_Enum_DistributionProfileActionStatus
{
	const DISABLED = 1;
	const AUTOMATIC = 2;
	const MANUAL = 3;
}

