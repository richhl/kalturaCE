<?php
class Kaltura_Client_ContentDistribution_Type_DistributionProviderFilter extends Kaltura_Client_ContentDistribution_Type_DistributionProviderBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaDistributionProviderFilter';
	}
	

}

