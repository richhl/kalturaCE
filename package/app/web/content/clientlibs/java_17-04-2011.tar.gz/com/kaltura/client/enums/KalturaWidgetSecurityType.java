package com.kaltura.client.enums;

/**
 * This class was generated using generate.php
 * against an XML schema provided by Kaltura.
 * @date Wed, 25 May 11 12:54:21 -0400
 * 
 * MANUAL CHANGES TO THIS CLASS WILL BE OVERWRITTEN.
 */
public enum KalturaWidgetSecurityType {
    NONE (1),
    TIMEHASH (2);

    int hashCode;

    KalturaWidgetSecurityType(int hashCode) {
        this.hashCode = hashCode;
    }

    public int getHashCode() {
        return this.hashCode;
    }

    public static KalturaWidgetSecurityType get(int hashCode) {
        switch(hashCode) {
            case 1: return NONE;
            case 2: return TIMEHASH;
            default: return NONE;
        }
    }
}
